function Spinner() {
  return (
    <div className='loading_container'>
      <div className='spinner'></div>
    </div>
  )
}

export default Spinner